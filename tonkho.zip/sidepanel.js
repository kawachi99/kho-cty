const GIST_URL = "https://gist.githubusercontent.com/kawachi99/10c54c3708ae2eb2c477d519dc0b248f/raw/extension-config.json";

async function checkUpdate() {
    const banner = document.getElementById('update-banner');
    const iframe = document.getElementById('content-iframe');

    try {
        // Fetch dữ liệu từ GitHub
        const response = await fetch(`${GIST_URL}?t=${Date.now()}`, { cache: "no-store" });
        const config = await response.json();

        const latestVersion = config.web_version;
        const lastSeenVersion = localStorage.getItem('lastSeenWebVersion');

        // Nếu phát hiện phiên bản mới và chưa được xác nhận
        if (latestVersion !== lastSeenVersion) {
            banner.style.display = 'block';
            
            banner.onclick = () => {
                localStorage.setItem('lastSeenWebVersion', latestVersion);
                banner.style.display = 'none';
                
                // Cập nhật lại URL mới cho iframe nếu cần
                if (iframe.src !== config.target_url) {
                    iframe.src = config.target_url;
                } else {
                    location.reload(); 
                }
            };
        } else {
            // Nếu đã trùng phiên bản thì ẩn banner đi (đề phòng trường hợp bạn hạ version trên Gist)
            banner.style.display = 'none';
        }

        // Trả về URL để dùng cho lần load đầu tiên
        return config.target_url;
    } catch (error) {
        console.error('Lỗi kiểm tra cập nhật:', error);
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    const iframe = document.getElementById('content-iframe');
    const messageBox = document.getElementById('message-box');

    // 1. Kiểm tra lần đầu khi vừa mở
    const targetUrl = await checkUpdate();
    if (targetUrl) iframe.src = targetUrl;

    iframe.onload = () => {
        messageBox.style.display = 'none';
        iframe.style.display = 'block';
    };

    // 2. Tự động kiểm tra mỗi 30 giây (30000ms)
    // Người dùng đang dùng vẫn sẽ thấy banner hiện lên nếu bạn vừa sửa Gist
    setInterval(checkUpdate, 30000); 
});