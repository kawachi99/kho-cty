const GIST_URL = "https://gist.githubusercontent.com/kawachi99/10c54c3708ae2eb2c477d519dc0b248f/raw/extension-config.json";

async function checkUpdate() {
    const banner = document.getElementById('update-banner');
    const iframe = document.getElementById('content-iframe');

    try {
        const response = await fetch(`${GIST_URL}?t=${Date.now()}`, { cache: "no-store" });
        const config = await response.json();

        const latestVersion = config.web_version;
        const lastSeenVersion = localStorage.getItem('lastSeenWebVersion');

        if (latestVersion !== lastSeenVersion) {
            banner.style.display = 'block';
            
            banner.onclick = () => {
                localStorage.setItem('lastSeenWebVersion', latestVersion);
                banner.style.display = 'none';
                if (iframe.src !== config.target_url) {
                    iframe.src = config.target_url;
                } else {
                    location.reload(); 
                }
            };
        } else {
            banner.style.display = 'none';
        }
        return config.target_url;
    } catch (error) {
        console.error('Lỗi kiểm tra cập nhật:', error);
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    const iframe = document.getElementById('content-iframe');
    const messageBox = document.getElementById('message-box');

    const targetUrl = await checkUpdate();
    if (targetUrl) iframe.src = targetUrl;

    iframe.onload = () => {
        messageBox.style.display = 'none';
        iframe.style.display = 'block';
    };

    setInterval(checkUpdate, 30000); 
});