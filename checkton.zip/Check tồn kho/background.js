console.log('Background script đang chạy');

// Cho phép click vào icon để mở thẳng Sidepanel
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch((error) => console.error(error));

let latestToken = null;
let refreshTabId = null;

// Tạo menu chuột phải
chrome.contextMenus.create({
    id: "copyToken",
    title: "Copy Token & Reset",
    contexts: ["action"]
});

function getJwtExpiration(token) {
    try {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
        return JSON.parse(jsonPayload).exp * 1000;
    } catch (e) {
        console.error('Không thể giải mã JWT:', e);
        return null;
    }
}

function scheduleTokenRefresh(token) {
    const expTime = getJwtExpiration(token);
    if (!expTime) return;

    const currentTime = Date.now();
    const timeUntilRefresh = expTime - currentTime - 180000; 

    if (timeUntilRefresh > 0) {
        chrome.alarms.create('refreshTokenAlarm', { when: currentTime + timeUntilRefresh });
    } else {
        triggerSilentRefresh();
    }
}

function triggerSilentRefresh() {
    if (refreshTabId) return; 
    
    chrome.tabs.create({ url: "https://erp.phongvu.vn/", active: false }, (tab) => {
        refreshTabId = tab.id;
        
        setTimeout(() => {
            if (refreshTabId) {
                chrome.tabs.remove(refreshTabId).catch(() => {});
                refreshTabId = null;
            }
        }, 15000);
    });
}

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'refreshTokenAlarm') {
        triggerSilentRefresh();
    }
});

chrome.webRequest.onBeforeSendHeaders.addListener(
    function(details) {
        const headers = details.requestHeaders;
        let authHeader = headers.find(header => header.name.toLowerCase() === 'authorization');
        
        if (authHeader && authHeader.value.startsWith('Bearer ')) {
            const newToken = authHeader.value;
            
            if (newToken !== latestToken) {
                latestToken = newToken;
                chrome.storage.local.set({ token: latestToken });
                chrome.action.setBadgeText({ text: 'On' }); 
                chrome.action.setBadgeBackgroundColor({ color: '#4CAF50' });
                scheduleTokenRefresh(latestToken.replace('Bearer ', ''));
            }

            if (refreshTabId && details.tabId === refreshTabId) {
                chrome.tabs.remove(refreshTabId).catch(() => {});
                refreshTabId = null;
            }
        }
    },
    { urls: ["https://staff-bff.tekoapis.com/*", "https://erp.phongvu.vn/*"] },
    ["requestHeaders"]
);

chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
    if (message.request === 'loadToken') {
        chrome.storage.local.get(['token'], (result) => {
            if (result.token) {
                sendResponse({ token: result.token });
            } else {
                triggerSilentRefresh();
                sendResponse({ token: 'Chưa tìm thấy token, extension đang tự động lấy lại ngầm...' });
            }
        });
        return true;
    }
});

// XỬ LÝ SỰ KIỆN CLICK CHUỘT PHẢI - ẨN HOÀN TOÀN THÔNG BÁO
chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === 'copyToken') {
        chrome.storage.local.get(['token'], (result) => {
            const tokenToCopy = latestToken || result.token;

            if (!tokenToCopy) {
                triggerSilentRefresh();
                return;
            }

            if (tab.url && (tab.url.startsWith('chrome://') || tab.url.startsWith('edge://') || tab.url.startsWith('chrome-extension://'))) {
                return;
            }

            chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: (textToCopy) => {
                    try {
                        const textarea = document.createElement('textarea');
                        textarea.value = textToCopy;
                        textarea.style.position = 'fixed';
                        textarea.style.opacity = '0';
                        document.body.appendChild(textarea);
                        textarea.select();
                        const successful = document.execCommand('copy');
                        document.body.removeChild(textarea);
                        return successful;
                    } catch (err) {
                        return false;
                    }
                },
                args: [tokenToCopy]
            }).then((results) => {
                if (results && results[0] && results[0].result) {
                    // Xóa token cũ và lấy cái mới (không hiện thông báo nữa)
                    chrome.storage.local.remove('token');
                    latestToken = null;
                    chrome.action.setBadgeText({ text: '' });
                    chrome.alarms.clear('refreshTokenAlarm');
                    triggerSilentRefresh();
                }
            }).catch(err => {
                console.error(err);
            });
        });
    }
});